---
name: resume-optimizer
description: Tailor a resume or CV to a specific job description, including ATS keyword audit, truth-preserving bullet rewrites, summary rewrite, skills section optimization, and gap analysis.
when_to_use: Use when the user asks to optimize, tailor, improve, rewrite, or ATS-check a resume/CV for a role or job description.
argument-hint: "[resume file/text] [job description file/text]"
allowed-tools: Read Grep Glob Bash(python *) Bash(python3 *)
---

# Resume Optimizer

Use this skill to optimize a resume/CV for a job description.

## Operating rules

- Preserve truth. Never invent experience, numbers, titles, tools, certifications, or dates.
- Read the candidate resume/CV and job description when available.
- If local files are available, run the keyword audit script from the main skill if installed:
  - `python ${CLAUDE_SKILL_DIR}/../job-seeker-helper/scripts/keyword_audit.py --resume <resume> --job <jd> --format markdown`
- If the script is unavailable, perform the audit manually.
- Prefer concrete bullets with impact, scope, tools, and business context.
- Add missing keywords only when supported by the resume or the user's stated experience.

## Output

1. Role summary and hiring signals.
2. ATS keyword audit.
3. Match matrix.
4. Resume strategy.
5. Rewritten headline/summary.
6. Rewritten skills section.
7. Rewritten experience bullets.
8. Gaps and verification checklist.
9. Final tailored resume draft if enough information is available.

For detailed guidance, use the main skill resource if installed: `../job-seeker-helper/resources/resume_tailoring.md`.

$ARGUMENTS
