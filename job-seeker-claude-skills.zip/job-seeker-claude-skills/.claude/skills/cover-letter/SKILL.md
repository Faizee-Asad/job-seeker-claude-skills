---
name: cover-letter
description: Write a specific, non-generic cover letter for a target role using the candidate's resume/CV and job description. Includes alternate openings, email subject line, and fact-check notes.
when_to_use: Use when the user asks for cover letter, application letter, motivation letter, letter of interest, email to hiring manager, or a role-specific written application.
argument-hint: "[role/company] [resume file/text] [job description file/text] [tone]"
allowed-tools: Read Grep Glob
---

# Cover Letter Writer

Write a concise, specific cover letter that connects real candidate proof to the target role.

## Process

1. Identify role, company, hiring priorities, and tone from `$ARGUMENTS` plus any files/text provided.
2. Pull 2-3 strongest evidence points from the resume/CV.
3. Draft a letter with:
   - Specific opening tied to the role.
   - Evidence paragraph with concrete proof.
   - Company/team/role motivation based on available information.
   - Confident close.
4. Include a subject line if email-style.
5. Include 2 alternate openings.
6. Include a fact-check list.

## Rules

- Do not use generic filler.
- Do not repeat the resume line by line.
- Do not invent company facts or candidate achievements.
- Use placeholders for missing specifics: `[Hiring Manager]`, `[specific company reason]`, `[add metric if true]`.
- Default to 250-400 words unless the user asks otherwise.

For deeper guidance, use `../job-seeker-helper/resources/cover_letter.md` if available.

$ARGUMENTS
