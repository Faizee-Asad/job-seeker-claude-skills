---
name: interview-coach
description: Prepare a job candidate for recruiter screens, hiring manager interviews, technical/portfolio rounds, behavioral STAR answers, questions to ask, and follow-up strategy based on a job description and resume/CV.
when_to_use: Use when the user wants interview preparation, mock interview questions, STAR answers, recruiter screen prep, behavioral prep, technical prep, salary talking points, or questions to ask interviewers.
argument-hint: "[role/company] [resume file/text] [job description file/text] [interview type]"
allowed-tools: Read Grep Glob
---

# Interview Coach

Prepare the candidate to interview clearly and confidently for the target role.

## Process

1. Decode the role and likely interview competencies.
2. Identify the candidate's strongest positioning angle.
3. Identify possible concerns and truthful ways to address them.
4. Create recruiter screen answers.
5. Create hiring manager and behavioral questions.
6. Create technical/portfolio/case prep if relevant.
7. Build a STAR/CAR story bank.
8. Create questions the candidate should ask.
9. Add a final prep checklist.

## Output

- Role briefing.
- 30-second pitch.
- 90-second pitch.
- Likely questions and answer outlines.
- STAR story bank.
- Technical/case prep if relevant.
- Questions to ask.
- Follow-up email draft if useful.

For deeper guidance, use `../job-seeker-helper/resources/interview_prep.md` if available.

$ARGUMENTS
