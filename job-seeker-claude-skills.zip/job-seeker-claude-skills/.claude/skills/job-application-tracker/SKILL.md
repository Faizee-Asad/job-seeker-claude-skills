---
name: job-application-tracker
description: Create, update, and organize a job application tracker with companies, roles, URLs, statuses, dates, next actions, contacts, priorities, and notes.
when_to_use: Use when the user wants to track job applications, create a job tracker, add a role to a tracker, plan follow-ups, or organize a job search pipeline.
argument-hint: "[create/add/update] [company] [role] [status] [next action]"
allowed-tools: Read Bash(python *) Bash(python3 *) Bash(cat *) Bash(ls *)
---

# Job Application Tracker

Help the user organize job applications and follow-ups.

## Default fields

`company, role, job_url, status, date_found, date_applied, next_action, next_action_date, contact, source, priority, notes`

## Actions

- Create a new `job_tracker.csv`.
- Add one or more job rows.
- Suggest next follow-up dates.
- Summarize pipeline by status.
- Identify stale applications needing follow-up.

## Script usage

If available, use the main helper script:

```bash
python ${CLAUDE_SKILL_DIR}/../job-seeker-helper/scripts/job_tracker.py init --path job_tracker.csv
```

To add a row:

```bash
python ${CLAUDE_SKILL_DIR}/../job-seeker-helper/scripts/job_tracker.py add --path job_tracker.csv --company "Acme" --role "Data Analyst" --status "Applied" --next-action "Follow up"
```

If the script is unavailable, create or edit CSV manually.

$ARGUMENTS
