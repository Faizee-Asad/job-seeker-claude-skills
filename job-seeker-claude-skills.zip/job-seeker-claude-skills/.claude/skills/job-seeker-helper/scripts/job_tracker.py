#!/usr/bin/env python3
"""Create and update a simple job application tracker CSV."""
from __future__ import annotations

import argparse
import csv
from datetime import date
from pathlib import Path

FIELDS = [
    'company','role','job_url','status','date_found','date_applied','next_action','next_action_date','contact','source','priority','notes'
]


def ensure(path: Path) -> None:
    if not path.exists():
        with path.open('w', newline='', encoding='utf-8') as f:
            writer = csv.DictWriter(f, fieldnames=FIELDS)
            writer.writeheader()


def add_row(path: Path, values: dict) -> None:
    ensure(path)
    row = {field: values.get(field, '') for field in FIELDS}
    if not row['date_found']:
        row['date_found'] = date.today().isoformat()
    with path.open('a', newline='', encoding='utf-8') as f:
        writer = csv.DictWriter(f, fieldnames=FIELDS)
        writer.writerow(row)


def main() -> int:
    parser = argparse.ArgumentParser()
    sub = parser.add_subparsers(dest='cmd', required=True)

    init = sub.add_parser('init')
    init.add_argument('--path', default='job_tracker.csv')

    add = sub.add_parser('add')
    add.add_argument('--path', default='job_tracker.csv')
    for field in FIELDS:
        add.add_argument(f'--{field.replace("_", "-")}', default='')

    args = parser.parse_args()
    path = Path(args.path)
    if args.cmd == 'init':
        ensure(path)
        print(f'Created {path}')
    elif args.cmd == 'add':
        values = {field: getattr(args, field) for field in FIELDS}
        add_row(path, values)
        print(f'Added row to {path}')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
