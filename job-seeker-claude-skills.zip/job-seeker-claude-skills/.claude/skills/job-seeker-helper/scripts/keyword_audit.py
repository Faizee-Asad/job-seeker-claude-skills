#!/usr/bin/env python3
"""Deterministic keyword audit for resume/job-description matching.

Usage:
  python keyword_audit.py --resume resume.txt --job job.txt --out audit.json
  python keyword_audit.py --resume resume.txt --job job.txt --format markdown

Uses standard library only. This is not a hiring decision tool; it simply helps
Claude and the candidate see which job-description terms are visible in the resume.
"""
from __future__ import annotations

import argparse
import json
import re
from collections import Counter
from pathlib import Path
from typing import Iterable

STOPWORDS = {
    'a','an','and','are','as','at','be','by','for','from','has','have','in','is','it','its','of','on','or','our','that','the','their','this','to','we','with','you','your',
    'will','can','able','about','across','after','all','also','any','based','but','candidate','company','degree','etc','experience','including','into','job','like','more','must','new','not','other','over','preferred','related','role','should','such','team','than','through','using','within','work','working','years'
}

SKILL_HINTS = {
    'sql','python','java','javascript','typescript','react','node','aws','azure','gcp','excel','tableau','power bi','looker','dbt','airflow','spark','kafka','snowflake','bigquery','postgresql','mysql','mongodb','amplitude','mixpanel','jira','figma','salesforce','hubspot','seo','sem','ga4','google analytics','a/b testing','ab testing','experimentation','machine learning','nlp','api','rest','graphql','docker','kubernetes','terraform','ci/cd','git','linux','agile','scrum','stakeholder management','roadmap','product analytics','dashboarding','forecasting','budgeting','financial modeling','customer success','account management','lead generation','copywriting','content strategy','ux research'
}

WORD_RE = re.compile(r"[a-zA-Z][a-zA-Z0-9+#./-]*")


def normalize(text: str) -> str:
    text = text.lower().replace('&', ' and ')
    text = re.sub(r"\ba\s*/\s*b\b", "ab", text)
    return text


def words(text: str) -> list[str]:
    return [w for w in WORD_RE.findall(normalize(text)) if len(w) > 1 and w not in STOPWORDS]


def ngrams(tokens: list[str], n: int) -> Iterable[str]:
    for i in range(len(tokens) - n + 1):
        chunk = tokens[i:i+n]
        if any(t in STOPWORDS for t in chunk):
            continue
        yield ' '.join(chunk)


def extract_terms(text: str, max_terms: int = 80) -> list[tuple[str, int]]:
    tokens = words(text)
    counts: Counter[str] = Counter()
    counts.update(tokens)
    for n, weight in [(2, 3), (3, 4)]:
        for gram in ngrams(tokens, n):
            counts[gram] += weight

    # Boost common explicit skill phrases if present.
    low = normalize(text)
    for skill in SKILL_HINTS:
        if skill in low:
            counts[skill] += 8

    # Remove weak singletons unless they are skill hints.
    filtered = Counter({term: c for term, c in counts.items() if (c > 1 or term in SKILL_HINTS) and len(term) > 2})
    return filtered.most_common(max_terms)


def audit(resume_text: str, job_text: str) -> dict:
    job_terms = extract_terms(job_text)
    resume_low = normalize(resume_text)
    matched = []
    missing = []
    partial = []

    for term, score in job_terms:
        if term in resume_low:
            matched.append({'term': term, 'job_weight': score})
        else:
            parts = term.split()
            if len(parts) > 1 and any(p in resume_low for p in parts if p not in STOPWORDS):
                partial.append({'term': term, 'job_weight': score})
            else:
                missing.append({'term': term, 'job_weight': score})

    total_weight = sum(score for _, score in job_terms) or 1
    matched_weight = sum(item['job_weight'] for item in matched)
    partial_weight = sum(item['job_weight'] * 0.4 for item in partial)
    coverage = round((matched_weight + partial_weight) / total_weight * 100, 1)

    return {
        'coverage_score_percent': coverage,
        'matched_terms': matched[:30],
        'partial_terms': partial[:20],
        'missing_terms': missing[:30],
        'recommendations': [
            'Add missing terms only when they are truthful and supported by experience.',
            'Rewrite bullets so important tools and outcomes appear in context, not just in a skills list.',
            'Use exact job-description language for true must-have skills.',
            'Mark unknown metrics as placeholders; never invent numbers.'
        ]
    }


def markdown_report(result: dict) -> str:
    lines = [
        '# ATS Keyword Audit',
        '',
        f"**Coverage score:** {result['coverage_score_percent']}%",
        '',
        'This score is a rough visibility check, not an ATS guarantee.',
        '',
        '## Matched terms',
    ]
    lines += [f"- {i['term']}" for i in result['matched_terms']] or ['- None found']
    lines += ['', '## Partial terms',]
    lines += [f"- {i['term']}" for i in result['partial_terms']] or ['- None found']
    lines += ['', '## Missing terms to consider if true',]
    lines += [f"- {i['term']}" for i in result['missing_terms']] or ['- None found']
    lines += ['', '## Recommendations']
    lines += [f"- {r}" for r in result['recommendations']]
    return '\n'.join(lines) + '\n'


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument('--resume', required=True, help='Path to resume/CV text or Markdown file')
    parser.add_argument('--job', required=True, help='Path to job description text or Markdown file')
    parser.add_argument('--out', help='Output path')
    parser.add_argument('--format', choices=['json', 'markdown'], default='json')
    args = parser.parse_args()

    resume_text = Path(args.resume).read_text(encoding='utf-8')
    job_text = Path(args.job).read_text(encoding='utf-8')
    result = audit(resume_text, job_text)

    output = json.dumps(result, indent=2) if args.format == 'json' else markdown_report(result)
    if args.out:
        Path(args.out).write_text(output, encoding='utf-8')
    else:
        print(output)
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
