#!/usr/bin/env python3
"""Assemble Markdown job-search assets into one application packet."""
from __future__ import annotations

import argparse
from pathlib import Path

DEFAULT_ORDER = [
    'ats_keyword_audit.md',
    'role_match_matrix.md',
    'tailored_resume.md',
    'cover_letter.md',
    'recruiter_message.md',
    'interview_prep_pack.md',
    'follow_up_email.md',
]


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument('--dir', default='.', help='Directory containing Markdown assets')
    parser.add_argument('--out', default='application_packet.md')
    parser.add_argument('files', nargs='*', help='Optional explicit file order')
    args = parser.parse_args()

    base = Path(args.dir)
    files = args.files or DEFAULT_ORDER
    parts = ['# Application Packet', '']

    for name in files:
        path = base / name
        if not path.exists():
            continue
        parts.append(f'---\n\n<!-- Source: {name} -->\n')
        parts.append(path.read_text(encoding='utf-8').strip())
        parts.append('')

    Path(args.out).write_text('\n'.join(parts).strip() + '\n', encoding='utf-8')
    print(f'Wrote {args.out}')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
