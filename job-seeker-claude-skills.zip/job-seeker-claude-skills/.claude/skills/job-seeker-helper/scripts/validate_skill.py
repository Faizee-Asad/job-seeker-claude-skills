#!/usr/bin/env python3
"""Lightweight validation for Claude Skill folders.

Checks each SKILL.md for frontmatter, name, and description. Uses no external dependencies.
"""
from __future__ import annotations

import re
import sys
from pathlib import Path

NAME_RE = re.compile(r'^[a-z0-9-]{1,64}$')


def parse_frontmatter(text: str) -> dict[str, str]:
    if not text.startswith('---\n'):
        raise ValueError('missing opening frontmatter marker')
    end = text.find('\n---', 4)
    if end == -1:
        raise ValueError('missing closing frontmatter marker')
    block = text[4:end]
    data: dict[str, str] = {}
    for raw in block.splitlines():
        line = raw.strip()
        if not line or line.startswith('#'):
            continue
        if ':' not in line:
            continue
        key, value = line.split(':', 1)
        data[key.strip()] = value.strip().strip('"').strip("'")
    return data


def validate(path: Path) -> list[str]:
    errors: list[str] = []
    try:
        text = path.read_text(encoding='utf-8')
        data = parse_frontmatter(text)
    except Exception as exc:
        return [f'{path}: {exc}']

    name = data.get('name') or path.parent.name
    desc = data.get('description')
    if not NAME_RE.match(name):
        errors.append(f'{path}: invalid skill name {name!r}')
    if not desc or len(desc) < 20:
        errors.append(f'{path}: description missing or too short')
    if len(text.splitlines()) > 500:
        errors.append(f'{path}: SKILL.md should stay under 500 lines; move details to resources')
    return errors


def main(argv: list[str]) -> int:
    root = Path(argv[1]) if len(argv) > 1 else Path('.claude/skills')
    files = sorted(root.glob('**/SKILL.md'))
    if not files:
        print(f'No SKILL.md files found under {root}', file=sys.stderr)
        return 1
    errors: list[str] = []
    for file in files:
        errors.extend(validate(file))
    if errors:
        print('\n'.join(errors), file=sys.stderr)
        return 1
    print(f'Validated {len(files)} skills')
    return 0


if __name__ == '__main__':
    raise SystemExit(main(sys.argv))
