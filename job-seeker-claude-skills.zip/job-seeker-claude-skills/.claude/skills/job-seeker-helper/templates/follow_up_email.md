# Follow-Up Email

Subject: Thank you — [Role]

Hi [Name],

Thank you for taking the time to speak with me about the [Role] position. I enjoyed discussing [specific topic] and learning more about [team/project].

After our conversation, I am even more interested in the opportunity to contribute to [specific outcome]. My experience with [proof point] feels especially relevant to the work you described.

Please let me know if I can share anything else.

Best,
[Name]
