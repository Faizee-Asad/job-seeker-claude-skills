# [FIRST LAST]
[City, Country] | [Email] | [Phone] | [LinkedIn] | [Portfolio/GitHub]

## [TARGETED HEADLINE]

## Summary
[2-4 lines tailored to the target role. Include domain, years/scope if true, key tools, and outcomes.]

## Skills
**Core:** [Skill], [Skill], [Skill]
**Tools:** [Tool], [Tool], [Tool]
**Methods:** [Method], [Method], [Method]

## Experience

### [Company] — [Title]
[Location] | [Month YYYY – Month YYYY]
- [Impact/action/scope/tool/result bullet]
- [Impact/action/scope/tool/result bullet]
- [Impact/action/scope/tool/result bullet]

## Projects

### [Project Name]
- [Problem solved, tools used, outcome.]

## Education

[Degree] — [Institution]

## Certifications

[Certification, Issuer, Year]
