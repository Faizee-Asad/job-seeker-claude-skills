# Application Packet: [Role] at [Company]

## Contents

1. ATS keyword audit
2. Role match matrix
3. Tailored resume
4. Cover letter
5. Recruiter message
6. Interview prep pack
7. Follow-up email
8. Job tracker row

---

## Verification reminder

Please verify all dates, metrics, company names, tools, and personal information before submitting.
