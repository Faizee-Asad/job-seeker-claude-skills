# Recruiter Message

Hi [Name],

I saw the [Role] opening at [Company]. My background in [top skill/domain] seems aligned with the role, especially [proof point]. I have experience with [tools/skills] and have worked on [relevant outcome].

If the team is still reviewing candidates, I would be grateful for the chance to be considered. I am happy to share a tailored resume or answer any questions.

Best,
[Name]
