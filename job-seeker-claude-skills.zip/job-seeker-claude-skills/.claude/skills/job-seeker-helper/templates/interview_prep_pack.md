# Interview Prep Pack: [Role] at [Company]

## Positioning statement

[30-45 second intro]

## Top match points

1. [Match point]
2. [Match point]
3. [Match point]

## Recruiter screen questions

| Question | Answer outline |
|---|---|
| Tell me about yourself. | [outline] |
| Why this role? | [outline] |
| Salary expectations? | [outline] |

## Hiring manager questions

| Question | Strong answer angle |
|---|---|
| [Question] | [Answer angle] |

## Technical / portfolio prep

- [Topic]
- [Example project]
- [Tool or method]

## STAR story bank

### Story 1: [Theme]

- Situation:
- Task:
- Action:
- Result:
- Reflection:

## Questions to ask interviewers

1. [Question]
2. [Question]
3. [Question]

## Weak spots and honest bridges

- [Gap]: [honest bridge]
