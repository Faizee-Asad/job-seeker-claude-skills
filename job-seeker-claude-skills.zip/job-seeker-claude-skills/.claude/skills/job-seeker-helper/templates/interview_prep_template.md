# Interview Prep Pack: [Company] — [Role]

## Positioning

**Best-fit angle:** [One sentence]

**Likely hiring priorities:**
1. [Priority]
2. [Priority]
3. [Priority]

**Possible concerns to address:**
- [Concern] → [How to address truthfully]

## 30-second pitch

[Draft]

## 90-second pitch

[Draft]

## Likely recruiter questions

| Question | Strong answer outline |
|---|---|
| Tell me about yourself. | [Outline] |
| Why this role? | [Outline] |
| Compensation expectations? | [Outline] |

## Behavioral STAR stories

| Theme | Story | Action | Result | Use for |
|---|---|---|---|---|

## Role-specific questions

1. [Question]
   - What they are testing: [Competency]
   - Answer outline: [Outline]

## Questions to ask interviewers

1. [Question]
2. [Question]
3. [Question]

## Final checklist

- [ ] Review company/product basics.
- [ ] Prepare 5 STAR stories.
- [ ] Prepare salary range.
- [ ] Prepare questions to ask.
- [ ] Test video/audio setup.
