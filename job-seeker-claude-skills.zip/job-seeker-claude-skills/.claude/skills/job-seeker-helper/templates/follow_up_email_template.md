Subject: Thank you — [Role] interview

Hi [Name],

Thank you for taking the time to speak with me about the [Role] role. I enjoyed learning more about [specific topic discussed].

Our conversation reinforced my interest in the role, especially the opportunity to contribute to [team goal/problem]. My experience with [relevant proof] seems closely aligned with what the team needs next.

Thanks again, and I look forward to hearing about next steps.

Best,
[Name]
