# [Candidate Name]

[City, Country] · [Email] · [Phone] · [LinkedIn] · [Portfolio/GitHub]

## Target Headline

[Target role title] | [Top skill 1] · [Top skill 2] · [Top skill 3]

## Summary

[2-4 lines tailored to the role. Use only truthful skills and experience.]

## Core Skills

- [Skill group]: [skills]
- [Tools]: [tools]
- [Domain]: [domain knowledge]

## Experience

### [Job Title], [Company]
[Dates]

- [Action + scope + tool/method + truthful impact]
- [Action + scope + tool/method + truthful impact]
- [Action + scope + tool/method + truthful impact]

## Projects

### [Project Name]

- [What was built, tools used, and result]

## Education

[Degree], [School]

## Certifications

[Certification, if true]
