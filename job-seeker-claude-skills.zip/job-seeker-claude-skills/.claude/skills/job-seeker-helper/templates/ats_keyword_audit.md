# ATS Keyword Audit

## Coverage score

`[score]%`

## Matched keywords

- `[keyword]` — `[where it appears in resume]`

## Missing but relevant keywords

- `[keyword]` — Add only if supported by real experience.

## Unsupported keywords

- `[keyword]` — Do not add unless the candidate truly has this experience.

## Alternative phrasing

| Job description phrase | Resume phrase | Recommendation |
|---|---|---|
| `[JD term]` | `[resume term]` | `[rewrite suggestion]` |

## Next actions

1. Add truthful missing keywords.
2. Move strongest evidence into the summary and top bullets.
3. Leave unsupported requirements out or address them honestly in interview prep.
