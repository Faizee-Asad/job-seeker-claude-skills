[Date]

Dear [Hiring Manager/Team],

I’m excited to apply for the [Role] position at [Company]. The role’s focus on [JD priority 1], [JD priority 2], and [JD priority 3] closely matches my experience in [candidate proof area].

In my recent work at [Company/Project], I [specific action] using [tools/methods], which helped [measurable or concrete outcome]. I also [second relevant proof], giving me practical experience with the kind of [stakeholder/problem/system] work described in your posting.

What interests me most about this role is [specific role/company/team reason based on JD or provided context]. I would bring [strength 1], [strength 2], and [strength 3] to help the team [business outcome].

Thank you for your time and consideration. I’d welcome the opportunity to discuss how my background maps to what your team needs.

Best,
[Name]
