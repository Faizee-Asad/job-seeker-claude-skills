# Candidate Intake Questions

Ask only what is needed. Do not block progress if the user wants a draft now.

## Essentials

1. What role and company are you targeting?
2. Can you provide the job description?
3. Can you provide your current resume/CV?
4. What location, remote/hybrid preference, or work authorization constraints matter?
5. What tone do you want: concise, warm, confident, executive, startup, academic?

## Strong optional questions

1. Which achievements are you most proud of?
2. What metrics can you safely share?
3. What tools or skills should not be overstated?
4. What industries or tasks do you want to avoid?
5. What salary range or level are you targeting?
