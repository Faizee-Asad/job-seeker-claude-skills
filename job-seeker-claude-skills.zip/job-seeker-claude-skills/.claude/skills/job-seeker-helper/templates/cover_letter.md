# Cover Letter

Dear [Hiring Manager/Team],

I am interested in the [Role] position at [Company] because [specific role/company reason]. My background in [skill/domain] matches the role's need for [job requirement], especially through my work on [real example].

In my recent experience, I [proof point 1]. I also [proof point 2]. These experiences helped me build strengths in [tools/skills from JD], while staying focused on [business outcome].

What stands out about [Company] is [specific company/product/team detail if known]. I would be excited to bring my experience in [top skill] and [top skill] to help [team/company outcome].

Thank you for your time and consideration. I would welcome the chance to discuss how my background fits this role.

Sincerely,

[Name]
