# Example Resume Snippet

## Experience

### BrightApp — Data Analyst
- Built weekly reporting dashboards for product and marketing teams.
- Used SQL and Python to analyze user behavior.
- Helped product managers understand onboarding dropoff.
