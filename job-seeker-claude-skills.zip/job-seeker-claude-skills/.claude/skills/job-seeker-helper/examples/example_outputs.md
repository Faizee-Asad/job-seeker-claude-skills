# Example Output Snippets

## Improved bullet

Before:

- Built weekly reporting dashboards for product and marketing teams.

After:

- Built SQL-based product dashboards for product and marketing stakeholders, turning weekly user behavior reporting into a repeatable workflow for onboarding and funnel analysis.

## Cover letter opening

I’m excited to apply for the Product Data Analyst role at ExampleCo because the role sits directly at the intersection of product analytics, experimentation, and stakeholder storytelling—areas I’ve been building through dashboarding, SQL/Python analysis, and onboarding funnel work at BrightApp.
