# Example Job Description

Company: ExampleCo
Role: Product Data Analyst

We are looking for a Product Data Analyst to partner with product managers, design experiments, build dashboards, analyze funnels, and communicate insights to leadership. Must have SQL, product analytics, A/B testing, stakeholder communication, and dashboarding experience. Python, dbt, and Amplitude are nice to have.
