# Interview Prep Playbook

## Goal

Prepare candidates to explain their fit clearly, answer likely questions, and ask smart questions.

## Prep outputs

### 1. Role briefing

Summarize:

- What the company likely needs from this role.
- Top 5 competencies being tested.
- Likely concerns about the candidate based on resume/JD gaps.
- Best positioning angle.

### 2. Recruiter screen prep

Include answers for:

- Tell me about yourself.
- Why this role?
- Why this company?
- Walk me through your resume.
- Compensation expectations.
- Availability and work authorization, without adding legal advice.
- Reason for leaving/current search.

### 3. Hiring manager prep

Include:

- 5-10 likely behavioral questions.
- 5-10 role-specific questions.
- Answer outlines using STAR/CAR: Situation, Task, Action, Result or Context, Action, Result.
- Specific examples from the candidate background.

### 4. Technical/portfolio prep

For technical roles, create:

- Topic checklist.
- Practice tasks.
- Case interview or take-home strategy.
- Portfolio walkthrough script.

### 5. Story bank

Create reusable stories:

| Theme | Story title | Evidence | Metrics | Best for questions about |
|---|---|---|---|---|

Themes:

- Leadership.
- Conflict.
- Ambiguity.
- Failure/learning.
- Influence without authority.
- Technical depth.
- Customer impact.
- Speed/ownership.

### 6. Questions to ask interviewers

Create questions that show judgment:

- `What would success look like in the first 90 days?`
- `Where does this role most need leverage right now: strategy, execution, stakeholder alignment, or technical depth?`
- `What are the biggest reasons someone would struggle in this role?`

## Output format

- 30-second pitch.
- 90-second pitch.
- Role-specific question bank.
- STAR answer outlines.
- Questions to ask.
- Final prep checklist.
