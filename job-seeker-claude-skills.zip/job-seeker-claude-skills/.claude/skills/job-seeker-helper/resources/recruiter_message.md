# Recruiter Message Guide

## Goal

Write short messages that make it easy for a recruiter or hiring manager to understand fit.

## LinkedIn / email recruiter message

Use 80 to 140 words.

```text
Hi [Name], I saw the [Role] opening at [Company]. My background in [top skill/domain] seems aligned with the role, especially [proof point]. I have experience with [tools/skills] and have worked on [relevant outcome].

If the team is still reviewing candidates, I would be grateful for the chance to be considered. I am happy to share a tailored resume or answer any questions.

Best,
[Name]
```

## Hiring manager message

Use slightly more role-specific detail:

```text
Hi [Name], I am interested in the [Role] role on your team. The work around [team/problem] stood out because I have worked on [real related example]. My strongest match points are [skill 1], [skill 2], and [skill 3].

I applied through [source] and would welcome the chance to discuss how my experience could help [team outcome].
```

## Rules

- Do not sound desperate.
- Do not mention personal hardship unless the user explicitly asks and it is relevant.
- Keep it easy to reply to.
- Include a clear but polite ask.
