# Ethics and Truth Preservation

## Must not invent

Never invent or exaggerate:

- Employers.
- Job titles.
- Employment dates.
- Degrees, certifications, licenses, awards, publications, patents.
- Tools, languages, frameworks, platforms.
- Metrics, revenue, cost savings, user counts, team size.
- Security clearance, visa status, citizenship, or work authorization.
- Management scope.
- Client names or confidential projects.

## Allowed transformations

You may:

- Reorder content for relevance.
- Rewrite bullets for clarity.
- Translate experience into target-role language.
- Add true keywords that are already supported by the user's background.
- Suggest likely metrics to find, clearly labeled as prompts.
- Create placeholders for missing evidence.
- Recommend removing irrelevant details.

## Uncertainty handling

Use labels:

- `Confirmed:` directly supported by user content.
- `Likely but verify:` implied but not explicit.
- `Missing:` not present.
- `Placeholder:` user must fill before submission.

## Candidate consent

Before sending or submitting anything, remind the user to verify all facts.
