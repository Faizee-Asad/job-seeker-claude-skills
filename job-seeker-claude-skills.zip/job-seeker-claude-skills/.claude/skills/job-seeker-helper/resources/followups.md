# Recruiter Outreach and Follow-up Playbook

## Recruiter DM

Keep it short and specific.

Template:

```text
Hi [Name] — I saw the [Role] opening at [Company]. My background in [relevant proof] maps closely to the role’s focus on [JD priority]. I’d love to connect or share a short note on fit if you’re the right person for this search.
```

## LinkedIn connection note

Under 300 characters when needed:

```text
Hi [Name], I’m interested in the [Role] role at [Company]. My background in [skill/domain] aligns with [specific JD priority]. Would be great to connect.
```

## Post-application follow-up

Send 5-7 business days after applying unless the posting says not to contact.

```text
Subject: Following up on [Role] application

Hi [Name],

I applied for the [Role] role and wanted to briefly share why I’m excited about it. The posting’s focus on [priority] lines up with my experience in [proof].

I’d be grateful for the chance to discuss whether my background fits what the team needs.

Best,
[Name]
```

## Post-interview thank-you

Send within 24 hours.

Must include:

- Appreciation.
- One specific topic discussed.
- One reinforced proof point.
- Clear enthusiasm.

## Rejection response

Keep the relationship warm:

```text
Thank you for letting me know. I appreciate the chance to be considered. I remain interested in [Company/team] and would welcome being kept in mind for future roles where my background in [area] may be a stronger fit.
```
