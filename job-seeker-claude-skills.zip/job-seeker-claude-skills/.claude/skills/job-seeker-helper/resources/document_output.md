# Document Output Guidance

## Preferred behavior

When the user asks for a downloadable resume, cover letter, application packet, or tracker:

1. Use Claude's built-in document creation/editing skills if they are available in the environment.
2. Prefer `.docx` for resumes and cover letters because candidates often need editable files.
3. Prefer `.pdf` only for final submission copies when the user requests it.
4. Use `.csv` for job trackers unless the user asks for a spreadsheet.
5. If no document skill is available, create clean Markdown files and a CSV tracker.

## Resume formatting principles

- One page for early/mid-career unless the user's field expects longer CVs.
- Two pages acceptable for senior/executive, academic, federal, medical, or technical CVs.
- Use standard headings.
- Avoid tables for ATS unless user needs a designed version.
- Use consistent date formatting.
- Use bullet points with strong verbs.

## File naming

Use clear names:

- `[FirstName_LastName]_[Role]_Resume.md`
- `[FirstName_LastName]_[Company]_Cover_Letter.md`
- `[Company]_[Role]_Interview_Prep.md`
- `job_tracker.csv`

## Fallback Markdown resume structure

```markdown
# First Last
City, Country | email@example.com | LinkedIn | Portfolio

## Targeted Headline

## Summary

## Skills

## Experience

### Company — Title
Location | Month YYYY – Month YYYY
- Bullet

## Projects

## Education
```
