# Resume / CV Tailoring Playbook

## Goal

Increase recruiter and hiring-manager clarity by aligning the resume to the job description while keeping every claim true.

## Process

### 1. Decode the JD

Extract:

- Role title and seniority.
- Business domain.
- Must-have skills.
- Nice-to-have skills.
- Tools/platforms.
- Methodologies.
- Scope signals: team size, revenue, users, data scale, regions, stakeholders.
- Outcome signals: growth, cost, risk, reliability, speed, conversion, retention, quality.
- Soft-skill signals: stakeholder management, ambiguity, leadership, communication.

### 2. Audit current resume

Look for:

- Missing exact-match keywords that are true for the candidate.
- Bullets that list tasks but not impact.
- Achievements without scope.
- Skills buried too low.
- Old or irrelevant items taking premium space.
- Role titles or summaries that do not match the target market.

### 3. Build a match matrix

Use this table:

| JD requirement | Evidence from candidate | Resume location | Strength | Action |
|---|---|---|---|---|
| Requirement | Real proof | Experience/project/skills | Strong/Partial/Missing | Keep/rewrite/add/remove |

### 4. Rewrite bullets

Use one of these formulas:

- **Impact first:** Improved `[metric/outcome]` by doing `[action]` using `[tools/methods]` for `[scope/stakeholder]`.
- **Scope first:** Led `[project/process]` across `[team/scope]`, resulting in `[measurable outcome]`.
- **Problem first:** Solved `[problem]` by `[action]`, reducing/increasing `[metric]`.
- **Tool proof:** Built/used `[tool/system]` to `[business purpose]`, enabling `[outcome]`.

If exact metrics are missing, do not invent. Use:

- `[add % if true]`
- `[add revenue/cost/time metric if known]`
- `improved turnaround time` only if supported by the user's information.

### 5. Optimize sections

Recommended order for most roles:

1. Name + contact + links.
2. Targeted headline.
3. 2-4 line summary.
4. Skills grouped by relevance.
5. Experience.
6. Projects, education, certifications, publications as relevant.

For early-career candidates, move projects/education higher. For senior candidates, lead with scope and leadership.

## ATS guidance

- Use standard headings: Summary, Skills, Experience, Education, Projects, Certifications.
- Avoid text boxes, icons, images, columns that may parse poorly unless the user explicitly wants design-heavy formatting.
- Include exact tool and skill names when true.
- Use both acronym and full form when space allows: `Search Engine Optimization (SEO)`.
- Avoid keyword lists that cannot be supported by experience.

## Output format

For resume optimization, produce:

1. Role summary.
2. Keyword audit.
3. Match matrix.
4. Recommended resume strategy.
5. Rewritten summary.
6. Rewritten skills section.
7. Rewritten bullets by job/project.
8. Gaps/questions to confirm.
9. Final tailored resume draft if enough information is available.
