# Cover Letter Playbook

## Goal

Write a short, specific letter that connects candidate proof to company needs. It should not sound like a template.

## Default length

250-400 words unless the user asks otherwise.

## Structure

1. **Opening:** Name the role and a specific reason for fit.
2. **Evidence paragraph:** Show 1-2 relevant achievements tied to the job description.
3. **Company/role paragraph:** Explain why this company/team/problem is interesting, using only information provided or safely inferable from the JD.
4. **Close:** Confident, simple call to action.

## Tone options

- Concise professional.
- Warm and human.
- Confident executive.
- Startup direct.
- Academic/research.
- Career switcher.

## Rules

- Do not repeat the resume line by line.
- Do not overpraise the company with generic flattery.
- Avoid "I am writing to express my interest" unless the user wants traditional style.
- Include exact role/company names if known.
- Use proof, not adjectives.
- For career switchers, translate prior experience into the target role's language.

## Strong opening examples

- `I’m excited to apply for the Data Analyst role at Acme because the position sits exactly at the intersection of product analytics, stakeholder storytelling, and experimentation work I’ve been doing in my recent projects.`
- `Your posting for a Customer Success Manager emphasizes renewal risk, onboarding quality, and executive communication. Those are the same problems I handled while supporting enterprise accounts at [Company].`

## Weak phrases to avoid

- `I am a perfect fit`
- `Ever since I was young`
- `Your esteemed organization`
- `I believe my skills and experience make me an ideal candidate`
- `Please find attached`

## Output format

Provide:

- Subject line if email-style.
- Cover letter body.
- 2 optional alternate openings.
- Notes on what facts the user should verify.
