# Cover Letter Guide

## Goal

Write a concise, specific cover letter that connects the candidate's real background to the role.

## Recommended length

250 to 400 words unless the user asks for a different length.

## Structure

1. Specific opening: role, company, and one direct reason for fit.
2. Evidence paragraph: 2 to 3 proof points mapped to the JD.
3. Company/team alignment: why this role or company makes sense.
4. Close: confident, simple, and low-pressure.

## Tone

Default tone: warm, confident, direct, human.

Avoid:

- generic "I am writing to express my interest"
- exaggerated passion
- repeating the resume line by line
- unsupported claims
- buzzword stuffing

## Template

```markdown
Dear [Hiring Manager/Team],

I am interested in the [Role] position at [Company] because [specific reason tied to the role]. My background in [skill/domain] matches the need for [job requirement], especially through my work on [real example].

In my recent experience, I [proof point 1]. I also [proof point 2]. These experiences helped me build strengths in [tools/skills from JD], while staying focused on [business outcome].

What stands out about [Company] is [specific company/product/team detail if known]. I would be excited to bring my experience in [top skill] and [top skill] to help [team/company outcome].

Thank you for your time and consideration. I would welcome the chance to discuss how my background fits this role.

Sincerely,
[Name]
```

If the company-specific detail is unknown, keep it role-specific instead of inventing research.
